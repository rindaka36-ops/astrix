package com.skibidi.debug;

import com.skibidi.debug.modules.AFKFly;
import com.skibidi.debug.modules.AmethystESP;
import com.skibidi.debug.modules.AutoRTPHome;
import com.skibidi.debug.modules.AutoRelog;
import com.skibidi.debug.modules.CustomFreecam;
import com.skibidi.debug.modules.FakePay;
import com.skibidi.debug.modules.FakeScoreboard;
import com.skibidi.debug.modules.FakeSpawner;
import com.skibidi.debug.modules.HomeSeter;
import com.skibidi.debug.modules.RegionMap;
import com.skibidi.debug.modules.RelogHelper;
import com.skibidi.debug.modules.RenderDistanceBypass;
import com.skibidi.debug.modules.SpawnerChunk;
import com.skibidi.debug.modules.SpawnerNotifier;
import com.skibidi.debug.modules.SpawnerTags;
import com.skibidi.debug.modules.SpotifyHUD;
import com.skibidi.debug.modules.StaffDetector;
import com.skibidi.debug.modules.StaffList;
import com.skibidi.debug.modules.StorageDensityScanner;
import com.skibidi.debug.modules.SusChunkFinder;
import meteordevelopment.meteorclient.addons.MeteorAddon;
import meteordevelopment.meteorclient.systems.modules.Category;
import meteordevelopment.meteorclient.systems.modules.Module;
import meteordevelopment.meteorclient.systems.modules.Modules;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class SkibidiDebugAddon extends MeteorAddon {
    private static final Logger LOG = LoggerFactory.getLogger("skibidi-debug");

    /** Nửa thứ hai của addon (precompiled, libs/skibididebug-classes.jar). */
    private dev.skibididebug.Skibididebug skibidi;
    /** Đảm bảo nửa Skibididebug chỉ được khởi tạo 1 lần. */
    private boolean skibidiInitDone;
    private boolean categoriesRegistered;

    /**
     * Meteor gọi onRegisterCategories() TRƯỚC onInitialize().
     * Bản cũ chỉ tạo this.skibidi trong onInitialize() nên lúc đăng ký category nó vẫn là null
     * => category "Astrix debug+" không bao giờ được đăng ký
     * => module "skibidi-debug" (Bypass) và các module cùng category không hiện trong GUI.
     * Ở đây ta đăng ký category bằng trường static, không phụ thuộc thứ tự gọi.
     */
    @Override
    public void onRegisterCategories() {
        if (categoriesRegistered) return;
        categoriesRegistered = true;

        Modules.registerCategory((Category) SkibidiCategory.CATEGORY);
        Modules.registerCategory((Category) SkibidiCategory.MISC_V2);
        Modules.registerCategory((Category) SkibidiCategory.HUD_V1);

        try {
            Modules.registerCategory(dev.skibididebug.Skibididebug.CATEGORY);
        } catch (Throwable t) {
            LOG.error("Skibididebug category failed to register", t);
        }
    }

    @Override
    public void onInitialize() {
        Modules modules = Modules.get();
        modules.add((Module) new AmethystESP());
        modules.add((Module) new SpawnerChunk());
        modules.add((Module) new SpawnerNotifier());
        modules.add((Module) new StorageDensityScanner());
        modules.add((Module) new SusChunkFinder());
        modules.add((Module) new SpawnerTags());
        modules.add((Module) new StaffDetector());
        modules.add((Module) new RelogHelper());
        modules.add((Module) new AutoRelog());
        modules.add((Module) new HomeSeter());
        modules.add((Module) new AFKFly());
        modules.add((Module) new AutoRTPHome());
        modules.add((Module) new RenderDistanceBypass());
        modules.add((Module) new CustomFreecam());
        modules.add((Module) new SpotifyHUD());
        modules.add((Module) new StaffList());
        modules.add((Module) new FakeScoreboard());
        modules.add((Module) new FakePay());
        modules.add((Module) new FakeSpawner());
        modules.add((Module) new RegionMap());

        initSkibidiHalf();
    }

    /** Cô lập nửa Skibididebug: lỗi bên đó không được làm hỏng các module còn lại. */
    private void initSkibidiHalf() {
        if (skibidiInitDone) return;
        skibidiInitDone = true;
        try {
            this.skibidi = new dev.skibididebug.Skibididebug();
            this.skibidi.onInitialize();
            LOG.info("Skibididebug half initialised");
        } catch (Throwable t) {
            LOG.error("Skibididebug half failed to initialise", t);
            this.skibidi = null;
        }
    }

    @Override
    public String getPackage() {
        return "com.skibidi.debug";
    }
}

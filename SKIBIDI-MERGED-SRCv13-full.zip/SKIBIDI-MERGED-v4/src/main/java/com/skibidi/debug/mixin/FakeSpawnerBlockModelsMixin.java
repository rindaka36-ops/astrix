package com.skibidi.debug.mixin;

import com.skibidi.debug.modules.FakeSpawner;
import net.minecraft.class_1087;
import net.minecraft.class_2246;
import net.minecraft.class_2680;
import net.minecraft.class_773;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(value={class_773.class})
public class FakeSpawnerBlockModelsMixin {
    private static final ThreadLocal<Boolean> SWAPPING = ThreadLocal.withInitial(() -> false);

    /*
     * WARNING - Removed try catching itself - possible behaviour change.
     */
    @Inject(method={"method_3335"}, at={@At(value="HEAD")}, cancellable=true)
    private void swapToSpawner(class_2680 state, CallbackInfoReturnable<class_1087> cir) {
        if (SWAPPING.get().booleanValue()) {
            return;
        }
        if (!FakeSpawner.shouldSwap(state.method_26204())) {
            return;
        }
        SWAPPING.set(true);
        try {
            class_2680 spawner = class_2246.field_10260.method_9564();
            class_1087 model = ((class_773)(Object)this).method_3335(spawner);
            if (model != null) {
                cir.setReturnValue(model);
            }
        }
        finally {
            SWAPPING.set(false);
        }
    }
}


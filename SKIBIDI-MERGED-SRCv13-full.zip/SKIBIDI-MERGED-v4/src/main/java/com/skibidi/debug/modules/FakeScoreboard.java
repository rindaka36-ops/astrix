package com.skibidi.debug.modules;

import com.skibidi.debug.SkibidiCategory;
import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import meteordevelopment.meteorclient.events.game.GameJoinedEvent;
import meteordevelopment.meteorclient.events.world.TickEvent;
import meteordevelopment.meteorclient.settings.BoolSetting;
import meteordevelopment.meteorclient.settings.Setting;
import meteordevelopment.meteorclient.settings.SettingGroup;
import meteordevelopment.meteorclient.settings.StringSetting;
import meteordevelopment.meteorclient.systems.modules.Module;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.class_2561;
import net.minecraft.class_266;
import net.minecraft.class_268;
import net.minecraft.class_269;
import net.minecraft.class_274;
import net.minecraft.class_5250;
import net.minecraft.class_8646;
import net.minecraft.class_9015;
import net.minecraft.class_9020;
import net.minecraft.class_9022;

public class FakeScoreboard
extends Module {
    private static final String[] ICONS = new String[]{"$", "\u2605", "\ud83d\udde1", "\u2620", "\u231a"};
    private static final int[] COLORS = new int[]{64512, 10683385, 0xFC0000, 16348675, 16573184};
    private static final Pattern PAT_BALANCE = Pattern.compile("(?i)^\\s*you have\\s*\\$\\s*[\\d,]+(?:\\.\\d+)?\\s*$");
    private static final String OBJ = "skibidi_fake_sb";
    private static final String TEAM = "skibidi_sb_t";
    private final SettingGroup sg;
    private final SettingGroup sgRows;
    public final Setting<String> title;
    public final Setting<Boolean> interceptBalance;
    public final Setting<Boolean> showMoney;
    public final Setting<String> money;
    public final Setting<Boolean> showStar;
    public final Setting<String> star;
    public final Setting<Boolean> showSword;
    public final Setting<String> sword;
    public final Setting<Boolean> showSkull;
    public final Setting<String> skull;
    public final Setting<Boolean> showClock;
    public final Setting<String> clock;
    private class_266 customObj;
    private String originalObjName;
    private final List<String> teamNames;

    public FakeScoreboard() {
        super(SkibidiCategory.MISC_V2, "fake-scoreboard", "Injects a fake sidebar scoreboard with custom stats.");
        this.sg = this.settings.getDefaultGroup();
        this.sgRows = this.settings.createGroup("Rows");
        this.title = this.sg.add((Setting)((StringSetting.Builder)((StringSetting.Builder)((StringSetting.Builder)((StringSetting.Builder)new StringSetting.Builder().name("title")).description("Scoreboard title.")).defaultValue("Nxdih")).onChanged(v -> this.reapply())).build());
        this.interceptBalance = this.sg.add((Setting)((BoolSetting.Builder)((BoolSetting.Builder)((BoolSetting.Builder)new BoolSetting.Builder().name("intercept-balance")).description("Auto-update balance from 'you have $X' chat messages.")).defaultValue(true)).build());
        this.showMoney = this.sgRows.add((Setting)((BoolSetting.Builder)((BoolSetting.Builder)((BoolSetting.Builder)((BoolSetting.Builder)new BoolSetting.Builder().name("show-balance")).description("Show balance row.")).defaultValue(true)).onChanged(v -> this.reapply())).build());
        this.money = this.sgRows.add((Setting)((StringSetting.Builder)((StringSetting.Builder)((StringSetting.Builder)((StringSetting.Builder)new StringSetting.Builder().name("balance")).description("Displayed balance (e.g. 64.9M).")).defaultValue("64.9M")).onChanged(v -> this.reapply())).build());
        this.showStar = this.sgRows.add((Setting)((BoolSetting.Builder)((BoolSetting.Builder)((BoolSetting.Builder)((BoolSetting.Builder)new BoolSetting.Builder().name("show-prestige")).description("Show prestige row.")).defaultValue(true)).onChanged(v -> this.reapply())).build());
        this.star = this.sgRows.add((Setting)((StringSetting.Builder)((StringSetting.Builder)((StringSetting.Builder)((StringSetting.Builder)new StringSetting.Builder().name("prestige")).description("Star / prestige count.")).defaultValue("20")).onChanged(v -> this.reapply())).build());
        this.showSword = this.sgRows.add((Setting)((BoolSetting.Builder)((BoolSetting.Builder)((BoolSetting.Builder)((BoolSetting.Builder)new BoolSetting.Builder().name("show-kills")).description("Show kills row.")).defaultValue(true)).onChanged(v -> this.reapply())).build());
        this.sword = this.sgRows.add((Setting)((StringSetting.Builder)((StringSetting.Builder)((StringSetting.Builder)((StringSetting.Builder)new StringSetting.Builder().name("kills")).description("Kill count.")).defaultValue("4")).onChanged(v -> this.reapply())).build());
        this.showSkull = this.sgRows.add((Setting)((BoolSetting.Builder)((BoolSetting.Builder)((BoolSetting.Builder)((BoolSetting.Builder)new BoolSetting.Builder().name("show-deaths")).description("Show deaths row.")).defaultValue(true)).onChanged(v -> this.reapply())).build());
        this.skull = this.sgRows.add((Setting)((StringSetting.Builder)((StringSetting.Builder)((StringSetting.Builder)((StringSetting.Builder)new StringSetting.Builder().name("deaths")).description("Death count.")).defaultValue("10")).onChanged(v -> this.reapply())).build());
        this.showClock = this.sgRows.add((Setting)((BoolSetting.Builder)((BoolSetting.Builder)((BoolSetting.Builder)((BoolSetting.Builder)new BoolSetting.Builder().name("show-playtime")).description("Show playtime row.")).defaultValue(true)).onChanged(v -> this.reapply())).build());
        this.clock = this.sgRows.add((Setting)((StringSetting.Builder)((StringSetting.Builder)((StringSetting.Builder)((StringSetting.Builder)new StringSetting.Builder().name("playtime")).description("Playtime label (e.g. 4h 34m).")).defaultValue("4h 34m")).onChanged(v -> this.reapply())).build());
        this.customObj = null;
        this.originalObjName = null;
        this.teamNames = new ArrayList<String>();
    }

    public void onActivate() {
        this.apply();
    }

    public void onDeactivate() {
        this.restore();
    }

    private void reapply() {
        if (this.isActive()) {
            this.mc.execute(this::apply);
        }
    }

    @EventHandler
    private void onGameJoined(GameJoinedEvent event) {
        this.originalObjName = null;
        this.customObj = null;
        this.mc.execute(this::apply);
    }

    @EventHandler
    private void onTick(TickEvent.Post event) {
        class_269 sb;
        class_266 cur;
        if (this.mc.field_1724 == null || this.mc.field_1687 == null) {
            return;
        }
        if (!(this.customObj == null || (cur = (sb = this.mc.field_1687.method_8428()).method_1189(class_8646.field_45157)) != null && cur.method_1113().equals(OBJ))) {
            this.apply();
        }
    }

    public void onChatMessage(String raw) {
        Matcher m;
        if (!this.isActive() || !((Boolean)this.interceptBalance.get()).booleanValue()) {
            return;
        }
        if (PAT_BALANCE.matcher(raw).matches() && (m = Pattern.compile("[\\d,]+(?:\\.\\d+)?").matcher(raw)).find()) {
            String found = m.group();
            this.mc.execute(() -> {
                ((StringSetting)this.money).set(FakeScoreboard.formatBalance(found));
                this.apply();
            });
        }
    }

    private void apply() {
        if (this.mc.field_1687 == null) {
            return;
        }
        class_269 sb = this.mc.field_1687.method_8428();
        class_266 cur = sb.method_1189(class_8646.field_45157);
        if (cur != null && !cur.method_1113().equals(OBJ)) {
            this.originalObjName = cur.method_1113();
        }
        this.removeCustom(sb);
        this.customObj = sb.method_1168(OBJ, class_274.field_1468, (class_2561)class_2561.method_43470((String)((String)this.title.get())), class_274.class_275.field_1472, false, (class_9022)class_9020.field_47557);
        sb.method_1158(class_8646.field_45157, this.customObj);
        boolean[] enabled = new boolean[]{(Boolean)this.showMoney.get(), (Boolean)this.showStar.get(), (Boolean)this.showSword.get(), (Boolean)this.showSkull.get(), (Boolean)this.showClock.get()};
        String[] values = new String[]{((String)this.money.get()).toUpperCase(), (String)this.star.get(), (String)this.sword.get(), (String)this.skull.get(), (String)this.clock.get()};
        int score = 0;
        for (boolean e : enabled) {
            if (!e) continue;
            ++score;
        }
        int slot = 0;
        for (int i = 0; i < 5; ++i) {
            if (!enabled[i]) {
                ++slot;
                continue;
            }
            String teamName = TEAM + slot;
            String fakeName = "\u00a7" + slot;
            this.teamNames.add(teamName);
            class_268 old = sb.method_1153(teamName);
            if (old != null) {
                sb.method_1191(old);
            }
            class_268 team = sb.method_1171(teamName);
            int rowColor = COLORS[i];
            class_5250 prefix = class_2561.method_43470((String)ICONS[i]).method_27694(s -> s.method_36139(rowColor)).method_10852((class_2561)class_2561.method_43470((String)(" " + values[i])).method_27694(s -> s.method_36139(0xFFFFFF)));
            team.method_1138((class_2561)prefix);
            sb.method_1172(fakeName, team);
            sb.method_1180(class_9015.method_55422((String)fakeName), this.customObj).method_55410(score--);
            ++slot;
        }
    }

    private void restore() {
        if (this.mc.field_1687 == null) {
            return;
        }
        class_269 sb = this.mc.field_1687.method_8428();
        class_266 toRestore = null;
        if (this.originalObjName != null) {
            toRestore = sb.method_1170(this.originalObjName);
        }
        sb.method_1158(class_8646.field_45157, toRestore);
        this.removeCustom(sb);
        this.originalObjName = null;
        this.customObj = null;
    }

    private void removeCustom(class_269 sb) {
        for (class_266 obj : new ArrayList<class_266>(sb.method_1151())) {
            if (!obj.method_1113().equals(OBJ)) continue;
            sb.method_1194(obj);
            break;
        }
        for (String name : this.teamNames) {
            class_268 t = sb.method_1153(name);
            if (t == null) continue;
            sb.method_1191(t);
        }
        this.teamNames.clear();
    }

    private static String formatBalance(String raw) {
        String clean = raw.replace(",", "");
        try {
            double v = Double.parseDouble(clean);
            if (v >= 1.0E9) {
                return String.format("%.1fB", v / 1.0E9);
            }
            if (v >= 1000000.0) {
                return String.format("%.1fM", v / 1000000.0);
            }
            if (v >= 1000.0) {
                return String.format("%.1fK", v / 1000.0);
            }
            return raw;
        }
        catch (NumberFormatException e) {
            return raw;
        }
    }
}


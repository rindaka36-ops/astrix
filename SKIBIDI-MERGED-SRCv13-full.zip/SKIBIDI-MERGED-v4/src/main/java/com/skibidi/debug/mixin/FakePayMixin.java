package com.skibidi.debug.mixin;

import com.skibidi.debug.modules.FakePay;
import net.minecraft.class_634;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(value={class_634.class})
public class FakePayMixin {
    @Inject(method={"method_45730"}, at={@At(value="HEAD")}, cancellable=true)
    private void interceptPayCommand(String command, CallbackInfo ci) {
        FakePay module = FakePay.INSTANCE;
        if (module == null || !module.isActive()) {
            return;
        }
        String[] parts = module.parse(command);
        if (parts == null) {
            return;
        }
        if (((Boolean)module.blockActual.get()).booleanValue()) {
            ci.cancel();
        }
        module.showReceipt(parts[0], parts[1]);
    }
}


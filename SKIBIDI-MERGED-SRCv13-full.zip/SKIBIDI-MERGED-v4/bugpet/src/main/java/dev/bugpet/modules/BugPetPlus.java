package dev.bugpet.modules;

import meteordevelopment.meteorclient.events.render.Render3DEvent;
import meteordevelopment.meteorclient.events.world.TickEvent;
import meteordevelopment.meteorclient.renderer.ShapeMode;
import meteordevelopment.meteorclient.settings.*;
import meteordevelopment.meteorclient.systems.modules.Category;
import meteordevelopment.meteorclient.systems.modules.Module;
import meteordevelopment.meteorclient.utils.render.RenderUtils;
import meteordevelopment.meteorclient.utils.render.color.Color;
import meteordevelopment.meteorclient.utils.render.color.SettingColor;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.registry.entry.RegistryEntry;
import net.minecraft.sound.SoundEvents;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.ChunkPos;
import net.minecraft.util.math.Direction;
import net.minecraft.util.shape.VoxelShape;
import net.minecraft.util.shape.VoxelShapes;
import net.minecraft.world.biome.Biome;
import net.minecraft.world.biome.BiomeKeys;
import net.minecraft.world.chunk.WorldChunk;

import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Deque;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicInteger;

public class BugPetPlus extends Module {
    private static final Direction[] HORIZONTAL = {Direction.NORTH, Direction.SOUTH, Direction.EAST, Direction.WEST};
    private static final Block[] CANDIDATES = {Blocks.DIORITE, Blocks.ANDESITE, Blocks.GRAVEL, Blocks.SAND, Blocks.DIRT};

    private final SettingGroup sgGeneral = settings.getDefaultGroup();
    private final SettingGroup sgRender = settings.createGroup("Render");

    private final Setting<Integer> scanRadius = sgGeneral.add(new IntSetting.Builder()
            .name("scan-radius").description("Chunk radius to scan.")
            .defaultValue(24).min(1).sliderRange(1, 32).build());
    private final Setting<Integer> chunksPerTick = sgGeneral.add(new IntSetting.Builder()
            .name("chunks-per-tick").defaultValue(16).min(1).sliderRange(1, 64).build());
    private final Setting<Integer> minVeinLength = sgGeneral.add(new IntSetting.Builder()
            .name("minimum-vein-length").defaultValue(5).min(2).sliderRange(2, 21).build());
    private final Setting<Boolean> noHoles = sgGeneral.add(new BoolSetting.Builder()
            .name("no-holes").description("Ignore chunks that contain mining holes.")
            .defaultValue(false).build());
    private final Setting<Boolean> chatNotification = sgGeneral.add(new BoolSetting.Builder()
            .name("chat-notification").defaultValue(true).build());

    private final Setting<SettingColor> chunkColor = sgRender.add(new ColorSetting.Builder()
            .name("chunk-color").defaultValue(new SettingColor(0, 255, 0, 40)).build());
    private final Setting<Boolean> blockHighlight = sgRender.add(new BoolSetting.Builder()
            .name("block-highlight").defaultValue(false).build());
    private final Setting<SettingColor> blockHighlightColor = sgRender.add(new ColorSetting.Builder()
            .name("block-highlight-color").defaultValue(new SettingColor(255, 20, 34, 85))
            .visible(blockHighlight::get).build());
    private final Setting<Boolean> showTracers = sgRender.add(new BoolSetting.Builder()
            .name("show-tracers").defaultValue(false).build());
    private final Setting<Integer> tracersAlpha = sgRender.add(new IntSetting.Builder()
            .name("tracers-alpha").defaultValue(70).range(0, 255).sliderRange(0, 255).build());

    private final AtomicInteger activeScans = new AtomicInteger(0);
    private final ConcurrentHashMap<ChunkPos, Block> detectedChunks = new ConcurrentHashMap<>();
    private final ConcurrentHashMap<ChunkPos, List<BlockPos>> detectedBlocks = new ConcurrentHashMap<>();
    private final Deque<ChunkPos> scanQueue = new ArrayDeque<>();
    private ChunkPos lastPlayerChunk;
    private ExecutorService scanner;

    public BugPetPlus(Category category) {
        super(category, "bugpet+", "Highlights suspicious vein columns where a green chunk appears.");
    }

    @Override
    public void onActivate() {
        clearDetections();
        scanner = Executors.newSingleThreadExecutor(r -> {
            Thread t = new Thread(r, "BugPetPlus-Scanner");
            t.setDaemon(true);
            return t;
        });
    }

    @Override
    public void onDeactivate() {
        if (scanner != null) {
            scanner.shutdownNow();
            try {
                scanner.awaitTermination(1L, TimeUnit.SECONDS);
            } catch (InterruptedException ignored) {
            }
            scanner = null;
        }
        clearDetections();
    }

    private void clearDetections() {
        scanQueue.clear();
        detectedChunks.clear();
        detectedBlocks.clear();
        lastPlayerChunk = null;
        activeScans.set(0);
    }

    // ---------- queueing ----------

    private void queueChunk(int x, int z) {
        if (mc.world != null && mc.world.isChunkLoaded(x, z)) {
            ChunkPos pos = new ChunkPos(x, z);
            if (!detectedChunks.containsKey(pos)) scanQueue.offer(pos);
        }
    }

    private void queueSurroundingChunks(ChunkPos c) {
        scanQueue.clear();
        int r = Math.max(1, scanRadius.get());
        for (int j = 0; j <= r; j++) {
            for (int k = -j; k <= j; k++) {
                queueChunk(c.x + k, c.z - j);
                if (j != 0) queueChunk(c.x + k, c.z + j);
            }
            for (int l = -j + 1; l < j; l++) {
                queueChunk(c.x - j, c.z + l);
                if (j != 0) queueChunk(c.x + j, c.z + l);
            }
        }
    }

    @EventHandler
    private void onTick(TickEvent.Post event) {
        if (mc.player == null || mc.world == null) return;

        ChunkPos cp = mc.player.getChunkPos();
        if (lastPlayerChunk == null || !lastPlayerChunk.equals(cp)
                || (scanQueue.isEmpty() && activeScans.get() == 0)) {
            lastPlayerChunk = cp;
            queueSurroundingChunks(cp);
        }

        int perTick = Math.max(1, chunksPerTick.get());
        int maxActive = perTick * 2;
        int submitted = 0;

        while (submitted < perTick && activeScans.get() < maxActive && !scanQueue.isEmpty()) {
            ChunkPos pos = scanQueue.poll();
            if (pos == null) break;

            if (mc.world.isChunkLoaded(pos.x, pos.z) && !detectedChunks.containsKey(pos)) {
                WorldChunk chunk;
                try {
                    chunk = mc.world.getChunk(pos.x, pos.z);
                } catch (Throwable t) {
                    continue;
                }
                if (chunk != null && !chunk.isEmpty()) {
                    submitScan(chunk);
                    submitted++;
                }
            }
        }
    }

    private void submitScan(WorldChunk chunk) {
        if (scanner != null && !scanner.isShutdown()) {
            activeScans.incrementAndGet();
            scanner.submit(new ScanTask(chunk));
        }
    }

    // ---------- rendering ----------

    @EventHandler
    private void onRender3D(Render3DEvent event) {
        if (mc.player == null || detectedChunks.isEmpty()) return;

        SettingColor base = chunkColor.get();
        Color side = new Color(base.r, base.g, base.b, base.a);
        Color line = new Color(base.r, base.g, base.b, 255);
        Color tracer = new Color(base.r, base.g, base.b, tracersAlpha.get());

        for (ChunkPos cp : detectedChunks.keySet()) {
            double x = cp.getStartX(), z = cp.getStartZ();
            event.renderer.box(x, 60.0, z, x + 16.0, 60.05, z + 16.0, side, line, ShapeMode.Both, 0);
            if (showTracers.get()) {
                event.renderer.line(RenderUtils.center.x, RenderUtils.center.y, RenderUtils.center.z,
                        x + 8.0, 60.0, z + 8.0, tracer);
            }
        }

        if (blockHighlight.get()) {
            SettingColor bc = blockHighlightColor.get();
            Color bSide = new Color(bc.r, bc.g, bc.b, Math.max(85, bc.a));
            Color bLine = new Color(bc.r, bc.g, bc.b, 255);
            for (List<BlockPos> list : detectedBlocks.values()) {
                if (list == null) continue;
                for (BlockPos p : list) {
                    event.renderer.box(p.getX(), p.getY(), p.getZ(), p.getX() + 1.0, p.getY() + 1.0, p.getZ() + 1.0,
                            bSide, bLine, ShapeMode.Both, 0);
                }
            }
        }
    }

    // ---------- detection ----------

    private void recordDetection(ChunkPos pos, Block block, List<BlockPos> list) {
        if (detectedChunks.putIfAbsent(pos, block) == null) {
            detectedBlocks.put(pos, list);
            notifyDetection(block, pos, list);
        }
    }

    private void notifyDetection(Block block, ChunkPos pos, List<BlockPos> list) {
        String name = displayName(block);
        String where;
        if (list != null && !list.isEmpty()) {
            BlockPos p = list.get(0);
            where = p.getX() + ", " + p.getY() + ", " + p.getZ();
        } else {
            where = "cx " + pos.x + " cz " + pos.z;
        }

        mc.execute(() -> {
            if (mc.player != null) {
                mc.player.playSound(SoundEvents.BLOCK_NOTE_BLOCK_CHIME.value(), 1.2F, 1.2F);
                if (chatNotification.get()) info("BugPet+: found %s at %s.", name, where);
            }
        });
    }

    private static String displayName(Block b) {
        if (b == Blocks.DIORITE) return "Diorite";
        if (b == Blocks.ANDESITE) return "Andesite";
        if (b == Blocks.GRAVEL) return "Gravel";
        if (b == Blocks.SAND) return "Sand";
        if (b == Blocks.DIRT) return "Dirt";
        if (b == Blocks.CLAY) return "Clay (River)";
        return "Unknown";
    }

    private boolean isCandidateBlock(Block b) {
        for (Block c : CANDIDATES) if (b == c) return true;
        return false;
    }

    private boolean isCandidateAt(Block block, BlockPos pos) {
        if (mc.world == null) return isCandidateBlock(block);
        if (block == Blocks.CLAY) return isBiome(mc.world.getBiome(pos), BiomeKeys.RIVER);
        if (block == Blocks.SAND) return !isBiome(mc.world.getBiome(pos), BiomeKeys.DESERT) && pos.getY() < 50;
        if (block == Blocks.DIRT) return pos.getY() < 50;
        return isCandidateBlock(block);
    }

    private static boolean isBiome(RegistryEntry<Biome> entry, net.minecraft.registry.RegistryKey<Biome> key) {
        if (entry == null) return false;
        try {
            return entry.matchesKey(key);
        } catch (Throwable t) {
            return false;
        }
    }

    // ---------- mining-hole check ----------

    private BlockState stateAt(WorldChunk chunk, BlockPos pos) {
        if ((pos.getX() >> 4) == chunk.getPos().x && (pos.getZ() >> 4) == chunk.getPos().z) {
            return chunk.getBlockState(pos);
        }
        return mc.world != null ? mc.world.getBlockState(pos) : Blocks.AIR.getDefaultState();
    }

    private boolean isOpenCell(WorldChunk chunk, BlockPos pos) {
        BlockState s = stateAt(chunk, pos);
        VoxelShape shape = s.getCollisionShape(mc.world != null ? mc.world : chunk.getWorld(), pos);
        return shape.isEmpty() || !VoxelShapes.fullCube().equals(shape);
    }

    private boolean isVerticalHole(WorldChunk c, BlockPos p) {
        return isOpenCell(c, p)
                && !isOpenCell(c, p.north()) && !isOpenCell(c, p.south())
                && !isOpenCell(c, p.east()) && !isOpenCell(c, p.west());
    }

    private boolean isEastWestHole(WorldChunk c, BlockPos p) {
        return isOpenCell(c, p) && isOpenCell(c, p.east(1)) && isOpenCell(c, p.east(2))
                && !isOpenCell(c, p.north()) && !isOpenCell(c, p.south())
                && !isOpenCell(c, p.east(3)) && !isOpenCell(c, p.west())
                && !isOpenCell(c, p.east(1).north()) && !isOpenCell(c, p.east(1).south())
                && !isOpenCell(c, p.east(2).north()) && !isOpenCell(c, p.east(2).south());
    }

    private boolean isNorthSouthHole(WorldChunk c, BlockPos p) {
        return isOpenCell(c, p) && isOpenCell(c, p.south(1)) && isOpenCell(c, p.south(2))
                && !isOpenCell(c, p.east()) && !isOpenCell(c, p.west())
                && !isOpenCell(c, p.south(3)) && !isOpenCell(c, p.north())
                && !isOpenCell(c, p.south(1).east()) && !isOpenCell(c, p.south(1).west())
                && !isOpenCell(c, p.south(2).east()) && !isOpenCell(c, p.south(2).west());
    }

    private interface HoleCheck {
        boolean test(WorldChunk c, BlockPos p);
    }

    /** Returns column height of the hole starting at m (0 if none). */
    private int holeHeight(WorldChunk chunk, BlockPos.Mutable m, HoleCheck check, int top) {
        if (!check.test(chunk, m)) return 0;
        BlockPos.Mutable t = new BlockPos.Mutable(m.getX(), m.getY(), m.getZ());
        while (check.test(chunk, t)) {
            t.move(Direction.UP);
            if (t.getY() >= top) break;
        }
        return t.getY() - m.getY();
    }

    private boolean containsMiningHoles(WorldChunk chunk) {
        if (chunk == null || chunk.isEmpty()) return false;

        int sx = chunk.getPos().getStartX();
        int sz = chunk.getPos().getStartZ();
        int bottom = chunk.getBottomY();
        int top = bottom + chunk.getHeight();
        BlockPos.Mutable m = new BlockPos.Mutable();

        for (int x = sx; x < sx + 16; x++) {
            for (int z = sz; z < sz + 16; z++) {
                int y = bottom;
                while (y < top) {
                    m.set(x, y, z);
                    int h = holeHeight(chunk, m, this::isVerticalHole, top);
                    if (h >= 4) return true;
                    if (h == 0) {
                        h = holeHeight(chunk, m, this::isEastWestHole, top);
                        if (h >= 4) return true;
                    }
                    if (h == 0) {
                        h = holeHeight(chunk, m, this::isNorthSouthHole, top);
                        if (h >= 4) return true;
                    }
                    y += h > 0 ? h : 1;
                }
            }
        }
        return false;
    }

    // ---------- background scan ----------

    private record VeinResult(Block block, List<BlockPos> positions) {}

    private final class ScanTask implements Runnable {
        private final WorldChunk chunk;
        private final ChunkPos chunkPos;

        ScanTask(WorldChunk chunk) {
            this.chunk = chunk;
            this.chunkPos = chunk.getPos();
        }

        @Override
        public void run() {
            try {
                if (Thread.currentThread().isInterrupted()) return;

                List<BlockPos> candidates = collectCandidates();
                if (candidates.isEmpty()) return;

                VeinResult vein = findVein(candidates);
                if (vein == null) return;

                if (!noHoles.get() || !containsMiningHoles(chunk)) {
                    mc.execute(() -> recordDetection(chunkPos, vein.block(), vein.positions()));
                }
            } finally {
                activeScans.decrementAndGet();
            }
        }

        private List<BlockPos> collectCandidates() {
            List<BlockPos> out = new ArrayList<>();
            int sx = chunkPos.getStartX(), sz = chunkPos.getStartZ();
            int bottom = chunk.getBottomY();
            int top = chunk.getTopYInclusive() + 1;
            BlockPos.Mutable m = new BlockPos.Mutable();

            for (int y = bottom; y < top; y++) {
                for (int dx = 0; dx < 16; dx++) {
                    for (int dz = 0; dz < 16; dz++) {
                        m.set(sx + dx, y, sz + dz);
                        Block b = chunk.getBlockState(m).getBlock();
                        if (isCandidateAt(b, m)) out.add(m.toImmutable());
                    }
                }
            }
            return out;
        }

        private VeinResult findVein(List<BlockPos> list) {
            int minLen = Math.max(2, minVeinLength.get());
            Map<BlockPos, Block> cache = new ConcurrentHashMap<>();

            for (BlockPos pos : list) {
                if (Thread.currentThread().isInterrupted()) return null;

                Block block = cached(pos, cache);
                if (!isCandidateAt(block, pos) || cached(pos.up(), cache).equals(block)) continue;

                int len = 1;
                for (BlockPos p = pos.down(); len <= 21 && cached(p, cache).equals(block); p = p.down()) len++;

                int need = (block == Blocks.DIRT || block == Blocks.SAND) ? Math.max(5, minLen) : minLen;
                if (len < need) continue;

                boolean enclosed = true;
                for (int l = 0; l < len && enclosed; l++) {
                    BlockPos bp = pos.down(l);
                    for (Direction d : HORIZONTAL) {
                        if (!cached(bp.offset(d), cache).equals(Blocks.STONE)) {
                            enclosed = false;
                            break;
                        }
                    }
                }

                if (enclosed) {
                    List<BlockPos> column = new ArrayList<>(len);
                    for (int i = 0; i < len; i++) column.add(pos.down(i));
                    return new VeinResult(block, column);
                }
            }
            return null;
        }

        private Block cached(BlockPos pos, Map<BlockPos, Block> cache) {
            return cache.computeIfAbsent(pos, p -> {
                if ((p.getX() >> 4) == chunkPos.x && (p.getZ() >> 4) == chunkPos.z) {
                    return chunk.getBlockState(p).getBlock();
                }
                return mc.world != null ? mc.world.getBlockState(p).getBlock() : Blocks.AIR;
            });
        }
    }
}

package dev.bugpet.modules;

import meteordevelopment.meteorclient.events.render.Render3DEvent;
import meteordevelopment.meteorclient.events.world.BlockUpdateEvent;
import meteordevelopment.meteorclient.events.world.TickEvent;
import meteordevelopment.meteorclient.renderer.ShapeMode;
import meteordevelopment.meteorclient.settings.*;
import meteordevelopment.meteorclient.systems.modules.Category;
import meteordevelopment.meteorclient.systems.modules.Module;
import meteordevelopment.meteorclient.utils.render.RenderUtils;
import meteordevelopment.meteorclient.utils.render.color.Color;
import meteordevelopment.meteorclient.utils.render.color.SettingColor;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.sound.SoundEvents;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.ChunkPos;
import net.minecraft.world.LightType;
import net.minecraft.world.chunk.WorldChunk;

import java.util.*;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.LinkedBlockingQueue;

public class BugPet extends Module {
    private static final int[][] NEIGHBOR_OFFSETS =
            {{1, 0, 0}, {-1, 0, 0}, {0, 1, 0}, {0, -1, 0}, {0, 0, 1}, {0, 0, -1}};

    private final SettingGroup sgGeneral = settings.getDefaultGroup();
    private final SettingGroup sgRender = settings.createGroup("Render");

    private final Setting<Integer> sensitivity = sgGeneral.add(new IntSetting.Builder()
            .name("sensitivity").description("Minimum light anomalies for a chunk to count.")
            .defaultValue(12).min(1).sliderRange(1, 100).build());
    private final Setting<Integer> simDistance = sgGeneral.add(new IntSetting.Builder()
            .name("sim-distance").description("Chunk radius to scan around you.")
            .defaultValue(8).min(1).sliderRange(1, 32).build());

    private final Setting<SettingColor> chunkColor = sgRender.add(new ColorSetting.Builder()
            .name("chunk-color").defaultValue(new SettingColor(0, 255, 0, 40)).build());
    private final Setting<Boolean> showTracers = sgRender.add(new BoolSetting.Builder()
            .name("show-tracers").defaultValue(false).build());
    private final Setting<Integer> tracersAlpha = sgRender.add(new IntSetting.Builder()
            .name("tracers-alpha").defaultValue(70).range(0, 255).sliderRange(0, 255).build());

    private final Set<ChunkPos> notifiedChunks = ConcurrentHashMap.newKeySet();
    private final Map<ChunkPos, Integer> detectedChunks = new ConcurrentHashMap<>();
    private final Set<ChunkPos> queuedChunks = ConcurrentHashMap.newKeySet();
    private final Map<ChunkPos, ScanResult> scanResults = new ConcurrentHashMap<>();
    private final LinkedBlockingQueue<ChunkPos> scanQueue = new LinkedBlockingQueue<>();
    private final Set<ChunkPos> processedGroups = ConcurrentHashMap.newKeySet();
    private int ticks;

    public BugPet(Category category) {
        super(category, "bugpet", "Detects suspicious chunks via geode light anomalies.");
    }

    @Override
    public void onActivate() {
        resetState();
        queueNearbyChunks();
    }

    @Override
    public void onDeactivate() {
        resetState();
    }

    private void resetState() {
        scanQueue.clear();
        queuedChunks.clear();
        detectedChunks.clear();
        notifiedChunks.clear();
        scanResults.clear();
        processedGroups.clear();
        ticks = 0;
    }

    private void queueChunk(int x, int z) {
        ChunkPos pos = new ChunkPos(x, z);
        if (queuedChunks.add(pos)) scanQueue.offer(pos);
    }

    private void queueNearbyChunks() {
        if (mc.player == null || mc.world == null) return;
        ChunkPos c = mc.player.getChunkPos();
        int r = simDistance.get();
        for (int x = c.x - r; x <= c.x + r; x++) {
            for (int z = c.z - r; z <= c.z + r; z++) queueChunk(x, z);
        }
    }

    private boolean isInViewDistance(int x, int z) {
        if (mc.player == null) return false;
        int vd = mc.options.getViewDistance().getValue();
        ChunkPos c = mc.player.getChunkPos();
        return Math.abs(x - c.x) <= vd && Math.abs(z - c.z) <= vd;
    }

    @EventHandler
    private void onTick(TickEvent.Post event) {
        if (mc.player == null || mc.world == null) return;

        int scanned = 0;
        ChunkPos pos;
        while (scanned < 4 && (pos = scanQueue.poll()) != null) {
            queuedChunks.remove(pos);
            if (isInViewDistance(pos.x, pos.z) && mc.world.isChunkLoaded(pos.x, pos.z)) {
                scanChunk(mc.world.getChunk(pos.x, pos.z));
                scanned++;
            }
        }

        if (++ticks % 60 == 0) queueNearbyChunks();
    }

    @EventHandler
    private void onBlockUpdate(BlockUpdateEvent event) {
        if (mc.world == null) return;
        BlockState s = event.newState;
        if (s.isOf(Blocks.AMETHYST_BLOCK) || s.isOf(Blocks.BUDDING_AMETHYST) || s.isOf(Blocks.AMETHYST_CLUSTER)) {
            ChunkPos cp = new ChunkPos(event.pos);
            scanResults.remove(cp);
            processedGroups.clear();
            queueChunk(cp.x, cp.z);
        }
    }

    @EventHandler
    private void onRender3D(Render3DEvent event) {
        if (mc.player == null || detectedChunks.isEmpty()) return;

        SettingColor base = chunkColor.get();
        Color side = new Color(base.r, base.g, base.b, base.a);
        Color line = new Color(base.r, base.g, base.b, 255);
        Color tracer = new Color(base.r, base.g, base.b, tracersAlpha.get());

        for (ChunkPos cp : detectedChunks.keySet()) {
            double x = cp.getStartX(), z = cp.getStartZ();
            event.renderer.box(x, 60.0, z, x + 16.0, 60.05, z + 16.0, side, line, ShapeMode.Both, 0);
            if (showTracers.get()) {
                event.renderer.line(RenderUtils.center.x, RenderUtils.center.y, RenderUtils.center.z,
                        x + 8.0, 60.0, z + 8.0, tracer);
            }
        }
    }

    // ---------- scanning ----------

    private BlockPos findGeodeCenter(WorldChunk chunk) {
        long sx = 0, sy = 0, sz = 0;
        int n = 0;
        ChunkPos cp = chunk.getPos();
        BlockPos.Mutable m = new BlockPos.Mutable();

        for (int y = -58; y <= 30; y++) {
            for (int dx = 0; dx < 16; dx++) {
                for (int dz = 0; dz < 16; dz++) {
                    m.set(cp.getStartX() + dx, y, cp.getStartZ() + dz);
                    BlockState bs = chunk.getBlockState(m);
                    if (bs.isOf(Blocks.AMETHYST_BLOCK) || bs.isOf(Blocks.BUDDING_AMETHYST)) {
                        sx += m.getX();
                        sy += m.getY();
                        sz += m.getZ();
                        n++;
                    }
                }
            }
        }
        return n == 0 ? null : new BlockPos((int) (sx / n), (int) (sy / n), (int) (sz / n));
    }

    private Set<BlockPos> findLightAnomalies(WorldChunk chunk) {
        Set<BlockPos> result = new HashSet<>();
        BlockPos center = findGeodeCenter(chunk);
        if (center == null || mc.world == null) return result;

        BlockPos.Mutable m = new BlockPos.Mutable();
        BlockPos.Mutable nb = new BlockPos.Mutable();
        BlockPos.Mutable nb2 = new BlockPos.Mutable();

        for (int i = -8; i <= 8; i++) {
            for (int j = -8; j <= 8; j++) {
                for (int k = -8; k <= 8; k++) {
                    m.set(center.getX() + i, center.getY() + j, center.getZ() + k);
                    BlockState bs = mc.world.getBlockState(m);
                    if (!(bs.isOf(Blocks.AIR) || bs.isOf(Blocks.AMETHYST_CLUSTER))) continue;
                    if (mc.world.getLightLevel(LightType.BLOCK, m) != 0) continue;

                    boolean bright = false;
                    boolean found = false;
                    int fx = 0, fy = 0, fz = 0;

                    for (int[] o : NEIGHBOR_OFFSETS) {
                        nb.set(m.getX() + o[0], m.getY() + o[1], m.getZ() + o[2]);
                        int light = mc.world.getLightLevel(LightType.BLOCK, nb);
                        if (light > 4) {
                            bright = true;
                            break;
                        }
                        if (!found && light == 4 && mc.world.getBlockState(nb).isOf(Blocks.AIR)) {
                            found = true;
                            fx = nb.getX();
                            fy = nb.getY();
                            fz = nb.getZ();
                        }
                    }

                    if (!bright && found) {
                        boolean bright2 = false;
                        for (int[] o : NEIGHBOR_OFFSETS) {
                            nb2.set(fx + o[0], fy + o[1], fz + o[2]);
                            if (mc.world.getLightLevel(LightType.BLOCK, nb2) > 4) {
                                bright2 = true;
                                break;
                            }
                        }
                        if (!bright2) {
                            result.add(m.toImmutable());
                            if (result.size() >= 9000) return result;
                        }
                    }
                }
            }
        }
        return result;
    }

    private int[] dominantDirection(Set<BlockPos> set) {
        int[][] grid = new int[3][3];
        for (BlockPos p : set) {
            int x = p.getX() & 15, z = p.getZ() & 15;
            int gx = x < 6 ? 0 : x < 11 ? 1 : 2;
            int gz = z < 6 ? 0 : z < 11 ? 1 : 2;
            grid[gx][gz]++;
        }
        int bx = 1, bz = 1, best = -1;
        for (int a = 0; a < 3; a++) {
            for (int b = 0; b < 3; b++) {
                if (grid[a][b] > best) {
                    best = grid[a][b];
                    bx = a;
                    bz = b;
                }
            }
        }
        return new int[]{bx - 1, bz - 1};
    }

    private ScanResult analyze(WorldChunk chunk) {
        Set<BlockPos> set = findLightAnomalies(chunk);
        return new ScanResult(set.size(), set.isEmpty() ? new int[]{0, 0} : dominantDirection(set));
    }

    private void scanChunk(WorldChunk chunk) {
        if (mc.world == null) return;
        ChunkPos cp = chunk.getPos();
        ScanResult sr = analyze(chunk);
        scanResults.put(cp, sr);

        int threshold = sensitivity.get();
        if (sr.hits < threshold) return;

        List<ChunkPos> group = collectConnectedChunks(cp, threshold);
        if (group.isEmpty()) return;

        ChunkPos strongest = strongestChunk(group);
        if (!processedGroups.add(strongest)) return;

        long wx = 0, wz = 0, total = 0;
        for (ChunkPos g : group) {
            ScanResult r = scanResults.get(g);
            if (r != null) {
                wx += (long) g.x * r.hits;
                wz += (long) g.z * r.hits;
                total += r.hits;
            }
        }

        ChunkPos centroid = total == 0 ? strongest
                : new ChunkPos((int) Math.round((double) wx / total), (int) Math.round((double) wz / total));

        ChunkPos bestChunk = centroid;
        int bestHits = -1;
        int[] bestDir = {0, 0};

        for (int dx = -1; dx <= 1; dx++) {
            for (int dz = -1; dz <= 1; dz++) {
                ChunkPos p = new ChunkPos(centroid.x + dx, centroid.z + dz);
                ScanResult r = scanResults.get(p);
                if (r == null && mc.world.isChunkLoaded(p.x, p.z)) {
                    r = analyze(mc.world.getChunk(p.x, p.z));
                    scanResults.put(p, r);
                }
                if (r != null && r.hits > bestHits) {
                    bestHits = r.hits;
                    bestChunk = p;
                    bestDir = r.dir;
                }
            }
        }

        if (bestHits > 0) {
            recordDetection(new ChunkPos(bestChunk.x + bestDir[0], bestChunk.z + bestDir[1]), bestHits);
        }
    }

    private List<ChunkPos> collectConnectedChunks(ChunkPos start, int threshold) {
        List<ChunkPos> out = new ArrayList<>();
        Set<ChunkPos> seen = new HashSet<>();
        ArrayDeque<ChunkPos> stack = new ArrayDeque<>();
        stack.push(start);
        seen.add(start);

        while (!stack.isEmpty()) {
            ChunkPos cur = stack.pop();
            ScanResult r = scanResults.get(cur);
            if (r == null || r.hits < threshold) continue;
            out.add(cur);
            for (int dx = -1; dx <= 1; dx++) {
                for (int dz = -1; dz <= 1; dz++) {
                    if (dx == 0 && dz == 0) continue;
                    ChunkPos n = new ChunkPos(cur.x + dx, cur.z + dz);
                    ScanResult nr = scanResults.get(n);
                    if (seen.add(n) && nr != null && nr.hits >= threshold) stack.push(n);
                }
            }
        }
        return out;
    }

    private ChunkPos strongestChunk(List<ChunkPos> list) {
        return Collections.min(list,
                Comparator.<ChunkPos>comparingInt(c -> -scanResults.get(c).hits)
                        .thenComparingInt(c -> c.x)
                        .thenComparingInt(c -> c.z));
    }

    private void recordDetection(ChunkPos pos, int hits) {
        Integer old = detectedChunks.get(pos);
        if (old == null || old < hits) {
            detectedChunks.put(pos, hits);
            if (notifiedChunks.add(pos)) notifyDetection(pos);
            mergeNearbyDetections();
        }
    }

    private void notifyDetection(ChunkPos pos) {
        mc.execute(() -> {
            if (mc.player != null) {
                mc.player.playSound(SoundEvents.BLOCK_NOTE_BLOCK_CHIME.value(), 1.2F, 1.2F);
                info("BugPet: chunk found at cx %d cz %d.", pos.x, pos.z);
            }
        });
    }

    private void mergeNearbyDetections() {
        List<Map.Entry<ChunkPos, Integer>> list = new ArrayList<>(detectedChunks.entrySet());
        list.sort((a, b) -> Integer.compare(b.getValue(), a.getValue()));
        Set<ChunkPos> remove = new HashSet<>();

        for (int i = 0; i < list.size(); i++) {
            if (remove.contains(list.get(i).getKey())) continue;
            for (int j = i + 1; j < list.size(); j++) {
                ChunkPos a = list.get(i).getKey();
                ChunkPos b = list.get(j).getKey();
                if (Math.max(Math.abs(a.x - b.x), Math.abs(a.z - b.z)) <= 2) remove.add(b);
            }
        }
        remove.forEach(detectedChunks::remove);
    }

    private record ScanResult(int hits, int[] dir) {}
}

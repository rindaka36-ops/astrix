package dev.bugpet.modules;

import meteordevelopment.meteorclient.events.render.Render3DEvent;
import meteordevelopment.meteorclient.events.world.TickEvent;
import meteordevelopment.meteorclient.renderer.ShapeMode;
import meteordevelopment.meteorclient.settings.*;
import meteordevelopment.meteorclient.systems.modules.Category;
import meteordevelopment.meteorclient.systems.modules.Module;
import meteordevelopment.meteorclient.utils.render.color.Color;
import meteordevelopment.meteorclient.utils.render.color.SettingColor;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.sound.SoundEvents;
import net.minecraft.state.property.Properties;
import net.minecraft.util.math.ChunkPos;
import net.minecraft.util.math.Direction;
import net.minecraft.world.chunk.ChunkSection;
import net.minecraft.world.chunk.WorldChunk;

import java.util.*;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.atomic.AtomicBoolean;

/** Ex KrispyChunkFinder: flags chunks with lots of vines plus sideways (rotated) deepslate. */
public class BugKrispyPlus extends Module {
    private final SettingGroup sgGeneral = settings.getDefaultGroup();
    private final SettingGroup sgRender = settings.createGroup("Render");

    private final Setting<Integer> minVines = sgGeneral.add(new IntSetting.Builder()
            .name("min-vines").description("Vines needed in a chunk.")
            .defaultValue(55).min(1).sliderRange(1, 200).build());
    private final Setting<Integer> minRotated = sgGeneral.add(new IntSetting.Builder()
            .name("min-rotated-deepslate").description("Sideways deepslate blocks needed in a chunk.")
            .defaultValue(1).min(1).sliderRange(1, 20).build());
    private final Setting<Integer> vineMinY = sgGeneral.add(new IntSetting.Builder()
            .name("vine-min-y").defaultValue(16).sliderRange(-64, 100).build());
    private final Setting<Integer> vineMaxY = sgGeneral.add(new IntSetting.Builder()
            .name("vine-max-y").defaultValue(60).sliderRange(-64, 200).build());
    private final Setting<Boolean> autoRadius = sgGeneral.add(new BoolSetting.Builder()
            .name("auto-radius").description("Use view distance + 2 (max 25).").defaultValue(true).build());
    private final Setting<Integer> radius = sgGeneral.add(new IntSetting.Builder()
            .name("radius").defaultValue(10).min(2).sliderRange(2, 25)
            .visible(() -> !autoRadius.get()).build());
    private final Setting<Integer> interval = sgGeneral.add(new IntSetting.Builder()
            .name("scan-interval").description("Ticks between scans.")
            .defaultValue(5).min(1).sliderRange(1, 100).build());
    private final Setting<Boolean> notify = sgGeneral.add(new BoolSetting.Builder()
            .name("notify").description("Sound and chat message for each new chunk.").defaultValue(true).build());

    private final Setting<SettingColor> fillColor = sgRender.add(new ColorSetting.Builder()
            .name("fill-color").defaultValue(new SettingColor(0, 255, 0, 80)).build());
    private final Setting<SettingColor> lineColor = sgRender.add(new ColorSetting.Builder()
            .name("line-color").defaultValue(new SettingColor(0, 255, 0, 180)).build());
    private final Setting<Integer> renderY = sgRender.add(new IntSetting.Builder()
            .name("render-y").defaultValue(63).sliderRange(-64, 320).build());

    private volatile Set<ChunkPos> renderCache = Collections.emptySet();
    private final Set<ChunkPos> notified = ConcurrentHashMap.newKeySet();
    private final AtomicBoolean scanning = new AtomicBoolean(false);
    private ExecutorService scanExec;
    private int tickCount;

    public BugKrispyPlus(Category category) {
        super(category, "bug-krispy+", "Flags chunks with many vines and sideways deepslate.");
    }

    @Override
    public void onActivate() {
        renderCache = Collections.emptySet();
        notified.clear();
        tickCount = 0;
        scanning.set(false);
        scanExec = Executors.newSingleThreadExecutor(r -> {
            Thread t = new Thread(r, "bug-krispy-scanner");
            t.setDaemon(true);
            return t;
        });
    }

    @Override
    public void onDeactivate() {
        renderCache = Collections.emptySet();
        notified.clear();
        scanning.set(false);
        if (scanExec != null) {
            scanExec.shutdownNow();
            scanExec = null;
        }
    }

    @EventHandler
    private void onTick(TickEvent.Post event) {
        if (mc.world == null || mc.player == null || scanExec == null) return;
        if (++tickCount % interval.get() != 0) return;
        if (!scanning.compareAndSet(false, true)) return;

        ChunkPos center = mc.player.getChunkPos();
        int r = autoRadius.get() ? Math.min(25, mc.options.getClampedViewDistance() + 2) : radius.get();

        List<ChunkPos> positions = new ArrayList<>();
        List<WorldChunk> chunks = new ArrayList<>();
        for (int dx = -r; dx <= r; dx++) {
            for (int dz = -r; dz <= r; dz++) {
                WorldChunk wc = mc.world.getChunkManager().getWorldChunk(center.x + dx, center.z + dz, false);
                if (wc != null && !wc.isEmpty()) {
                    positions.add(wc.getPos());
                    chunks.add(wc);
                }
            }
        }

        int needVines = minVines.get();
        int needRot = minRotated.get();
        int yMin = vineMinY.get();
        int yMax = vineMaxY.get();

        try {
            scanExec.submit(() -> {
                try {
                    Set<ChunkPos> hits = new HashSet<>();
                    for (int i = 0; i < positions.size(); i++) {
                        WorldChunk wc = chunks.get(i);
                        if (countVines(wc, yMin, yMax, needVines) >= needVines
                                && countRotatedDeepslate(wc, needRot) >= needRot) {
                            hits.add(positions.get(i));
                        }
                    }
                    renderCache = Collections.unmodifiableSet(hits);

                    if (notify.get()) {
                        for (ChunkPos p : hits) {
                            if (notified.add(p)) announce(p);
                        }
                    }
                } catch (Exception ignored) {
                } finally {
                    scanning.set(false);
                }
            });
        } catch (Exception e) {
            scanning.set(false);
        }
    }

    private void announce(ChunkPos p) {
        mc.execute(() -> {
            if (mc.player != null) {
                mc.player.playSound(SoundEvents.BLOCK_NOTE_BLOCK_CHIME.value(), 1.2F, 1.2F);
                info("BugKrispy+: chunk at cx %d cz %d.", p.x, p.z);
            }
        });
    }

    private int countVines(WorldChunk chunk, int yMin, int yMax, int cap) {
        int count = 0;
        ChunkSection[] sections = chunk.getSectionArray();
        int minY = chunk.getBottomY();
        for (int si = 0; si < sections.length; si++) {
            int bottom = minY + si * 16;
            if (bottom + 15 < yMin || bottom > yMax) continue;
            ChunkSection section = sections[si];
            if (section == null || section.isEmpty()) continue;
            if (!section.hasAny(s -> s.isOf(Blocks.VINE))) continue;
            for (int lx = 0; lx < 16; lx++) {
                for (int ly = 0; ly < 16; ly++) {
                    int y = bottom + ly;
                    if (y < yMin || y > yMax) continue;
                    for (int lz = 0; lz < 16; lz++) {
                        if (section.getBlockState(lx, ly, lz).isOf(Blocks.VINE)) {
                            if (++count >= cap) return count;
                        }
                    }
                }
            }
        }
        return count;
    }

    private int countRotatedDeepslate(WorldChunk chunk, int cap) {
        int count = 0;
        ChunkSection[] sections = chunk.getSectionArray();
        int minY = chunk.getBottomY();
        for (int si = 0; si < sections.length; si++) {
            int bottom = minY + si * 16;
            if (bottom + 15 < 0 || bottom > 60) continue;
            ChunkSection section = sections[si];
            if (section == null || section.isEmpty()) continue;
            if (!section.hasAny(s -> s.isOf(Blocks.DEEPSLATE))) continue;
            for (int lx = 0; lx < 16; lx++) {
                for (int ly = 0; ly < 16; ly++) {
                    int y = bottom + ly;
                    if (y < 0 || y > 60) continue;
                    for (int lz = 0; lz < 16; lz++) {
                        BlockState s = section.getBlockState(lx, ly, lz);
                        if (s.isOf(Blocks.DEEPSLATE) && s.contains(Properties.AXIS)
                                && s.get(Properties.AXIS) != Direction.Axis.Y) {
                            if (++count >= cap) return count;
                        }
                    }
                }
            }
        }
        return count;
    }

    @EventHandler
    private void onRender3D(Render3DEvent event) {
        Set<ChunkPos> cache = renderCache;
        if (mc.player == null || cache.isEmpty()) return;

        SettingColor f = fillColor.get();
        SettingColor l = lineColor.get();
        Color fill = new Color(f.r, f.g, f.b, f.a);
        Color line = new Color(l.r, l.g, l.b, l.a);
        double y = renderY.get();

        for (ChunkPos c : cache) {
            double x = c.getStartX(), z = c.getStartZ();
            event.renderer.box(x, y, z, x + 16.0, y + 0.1, z + 16.0, fill, line, ShapeMode.Both, 0);
        }
    }
}

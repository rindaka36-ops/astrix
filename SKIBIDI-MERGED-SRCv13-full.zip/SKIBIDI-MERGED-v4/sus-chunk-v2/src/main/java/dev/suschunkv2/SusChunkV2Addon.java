package dev.suschunkv2;

import com.mojang.logging.LogUtils;
import dev.suschunkv2.modules.SusChunkFinderV2;
import meteordevelopment.meteorclient.addons.MeteorAddon;
import meteordevelopment.meteorclient.systems.modules.Category;
import meteordevelopment.meteorclient.systems.modules.Modules;
import org.slf4j.Logger;

/**
 * Sus Chunk Finder V2 (ported from chukl-addon). Nested inside the Skibidi jar.
 * The module is put into the existing "Astrix Finder" category, which the main addon
 * registers in onRegisterCategories() (always before any onInitialize()).
 */
public class SusChunkV2Addon extends MeteorAddon {
    public static final Logger LOG = LogUtils.getLogger();
    private static final String TARGET_CATEGORY = "Astrix Finder";

    @Override
    public void onInitialize() {
        try {
            Category target = null;
            for (Category c : Modules.loopCategories()) {
                if (TARGET_CATEGORY.equals(c.name)) {
                    target = c;
                    break;
                }
            }
            if (target == null) {
                LOG.error("SusChunkFinderV2: category '{}' not found, module not added", TARGET_CATEGORY);
                return;
            }
            Modules.get().add(new SusChunkFinderV2(target));
        } catch (Throwable t) {
            LOG.error("SusChunkFinderV2 failed to initialise", t);
        }
    }

    @Override
    public String getPackage() {
        return "dev.suschunkv2";
    }
}

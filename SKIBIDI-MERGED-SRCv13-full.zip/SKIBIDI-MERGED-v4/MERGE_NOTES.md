# Skibidi Debug (merged)

## Build
    gradlew build        ->  build/libs/skibidi-debug-1.0.0.jar   (single jar, drop into mods/)
(gradle.properties still points at G:/JDK21 – change org.gradle.java.home if your JDK lives elsewhere.)

## How the merge works
* Main addon (ex "P3nis Debug V5"): full source, package com.skibidi.debug (renamed, no "p3nis" left anywhere).
* Skibidi Debug   : only .class files were provided (no source), so it is bundled as
                    libs/skibididebug-classes.jar and booted from P3nisDebugAddon.onInitialize()
                    inside a try/catch (if that half ever fails, the other modules still load).
* One fabric.mod.json / one Meteor entrypoint / one jar.

## Rename (p3nis -> skibidi)
* Entry class SkibidiDebugAddon, mod id skibidi-debug, jar skibidi-debug-1.0.0.jar, package com.skibidi.debug
  (deliberately NOT under dev.skibididebug: Orbit matches lambda factories by package prefix and an overlap could mix them up).
* Categories: "Astrix Finder", "Astrix Extra", "Astrix Music" (+ the original "Skibididebug" category from the classes half).
* Module p3nis-finder -> skibidi-finder. Config folder is now config/skibididebug/ (old config/p3nis/ is simply ignored).

## Changes
* Module-name collision: both halves had a module called "region-map". The Skibidi one is now
  "skibidi-region-map" (patched in the class constant pool).
* Removed SpawnerRendererMixin (empty mixin targeting class_839, did nothing, only a startup-crash risk).
* AutoRTPHome: /sethome now sends the slot (/sethome <n>, like HomeSeter); rtp regions are sent as
  "/rtp eu central" (space) instead of "eu-central"; log text no longer claims it disables itself.

## Not done / needs input
* Skibidi Debug classes could not be edited at source level (no source). Bug fixes there need a decompile.
* Head textures for the Admin list: assets/skibididebug/textures/admin/<name>.png are NOT in the zip you sent.
* Nothing here could be compiled or run on my side (no Minecraft/Meteor jars, no network).

## FIX (debug pass)
* ROOT CAUSE module "skibidi-debug" không hiện: Meteor gọi onRegisterCategories() trước onInitialize();
  bản cũ chỉ tạo `skibidi` trong onInitialize() => category của nửa Skibididebug không bao giờ được đăng ký.
  Giờ đăng ký bằng `Skibididebug.CATEGORY` (static) ngay trong onRegisterCategories().
* gradle.properties: bỏ `org.gradle.java.home=G:/JDK21` (làm build lỗi trên mọi máy khác).
* gradlew: dùng GradleWrapperMain chuẩn.
* Mixin defaultRequire 1 -> 0: nếu signature Camera/ClientPlayNetworkHandler lệch bản MC thì chỉ tắt tính năng, không crash game.

## Custom Models merge
* custom-models-addon is in subproject custom-models/ (package dev.custommodels.addon, source untouched), nested into the main jar
  via `include project(':custom-models')` -> still ONE jar: build/libs/skibidi-debug-1.0.0.jar. Module "custom-models" is in the Render tab.
* Reason for a subproject: custom-models uses YARN names, this project uses INTERMEDIARY (class_XXXX).
* build.gradle: added the missing fabric-loader modImplementation line. Removed missing icon reference from fabric.mod.json.
* yarn_mappings=1.21.11+build.4 in gradle.properties is a guess - verify at fabricmc.net/develop.
* Not compiled here.

## FIX v4 (code pass)
* ChunkFinder: airPocket no longer inflated (run counter reset per run); hidden-ore now counts only player filler
  (cobble / cobbled deepslate / obsidian, >=4 faces) instead of natural stone; chunk marked scanned only once it is
  really loaded; vertical-vein uses longest ore run per column; queue rebuilt every 60 ticks (was 200).
* SusChunkFinder: new setting cocoa-min (default 10) – natural jungle cocoa no longer flags every chunk.
* TuffChunkFinder: no more worker thread; scans on the client thread, 4 chunks/tick (same detection rules/cooldown).
* custom-models: mixin config required=false, defaultRequire=0; no hard (CustomModelState) casts.
* skibidi-debug.mixins.json: required=false (a bad @Shadow/@Inject target now only disables that feature).
* BaseCalc is inside libs/skibididebug-classes.jar (no source) -> NOT changed.
* Still not compiled/run here.

## FIX v5 (finder bug pass)
* TuffChunkFinder: bo "Base chance: 40-100%" (la so random). Thong bao nay hien ly do that (Beehive / Cobbled deepslate / Dense vines / Dense seagrass / Repeaters) + toa do chunk. Hang doi quet chunk gan nguoi choi truoc, nen candidate la chunk gan nhat (truoc day la chunk dau hang = goc tay-bac).
* AmethystESP: chi bao chat 1 lan cho moi geode moi (truoc day lap lai moi 5 giay vi quet lai); bo qua chunk rong; xoa geode khi khong con du bud.
* SpawnerChunk: quet moi 20 tick thay vi moi tick; xoa danh sach khi doi world/dimension; xoa spawner da bi pha.
* StorageDensityScanner: diem chunk duoc cap nhat/xoa khi tuot duoi nguong hoac chunk ra xa; o ve nam o do cao trung binh cua cac ruong (truoc day nhay theo Y nguoi choi).
* Van chua compile/chay (khong co jar Minecraft/Meteor).

* libs/skibididebug-classes.jar da duoc dat lai dung cho (khong xoa/khong sua thu muc libs).

## FIX v5.1
* fabric.mod.json: them lai "icon": "assets/skibididebug/icon.png" (file icon.png van nam trong assets, truoc do bi bo nham).

## FIX v6
* Category cua nua Skibididebug doi ten: "Skibidi Debug Sourced by kydufi" -> "Astrix debug+" (patch constant pool trong libs/skibididebug-classes.jar).

## FIX v7 (custom-models)
* LivingEntityRendererMixin: @At target cua submitModel thieu descriptor nen Loom khong remap sang intermediary => mixin khong gan duoc, model khong doi. Da them descriptor day du (Model, Object, MatrixStack, RenderLayer, int x3, Sprite, int, CrumblingOverlayCommand)V.
* Chua compile/chay thu local; kiem tra bang cach build lai va xem custom-models co doi model trong game.

## FIX v8
* SusChunkFinder: them "render-filled-chunk" (mac dinh bat) + "chunk-fill-color" / "chunk-line-color" (do). Chunk bi flag duoc to day ca cot tu day world den tran (giong SpawnerChunk); tam phang o Y=63 cu van giu.
* Astrix Finder: bo module skibidi-finder (xoa SkibidiFinder.java + bo dang ky trong SkibidiDebugAddon).
* Chua compile/chay (khong co jar Minecraft/Meteor).

## v9 - Sus Chunk Finder V2
* Moi subproject `sus-chunk-v2/` (yarn, giong custom-models, nested vao jar chinh bang `include project(':sus-chunk-v2')`).
* Module `sus-chunk-finder-v2` = SusChunkFinder cua chukl-addon (heatmap theo cay/amethyst chua moc xong, smart-adjustment, rotated-deepslate...). Dat trong category "Astrix Finder".
* Entry `dev.suschunkv2.SusChunkV2Addon` tim category "Astrix Finder" qua Modules.loopCategories() trong onInitialize (categories luon duoc dang ky truoc). Neu khong thay thi chi log loi, khong crash.
* Module cu `sus-chunk-finder` giu nguyen. Mac dinh V2 chi bat amethyst; render la tam do phang Y=63 (chinh chunk-thickness de thanh cot).
* Chua compile/chay (khong co jar Minecraft/Meteor). Neu yarn_mappings build.4 sai thi sua trong gradle.properties.

## v10 - BugPet / BugPet+
* Subproject `bugpet/` (yarn, nested vao jar chinh bang `include project(':bugpet')`), package dev.bugpet.
* Module `bugpet` = Chunk Finder cu (geode light anomaly); module `bugpet+` = Chunk Finder v2 cu (vein cot kep trong stone).
* Dat trong category "Astrix Finder" (tim qua Modules.loopCategories(), giong sus-chunk-v2).
* yarn_mappings doi build.4 -> build.5 (build.5 la ban client goc dung). Neu sai thi sua gradle.properties.
* Them .github/workflows/build.yml de build bang GitHub Actions ra 1 jar skibidi-debug-1.0.0.jar.
* Chua compile/chay.

## v11 - BugKrispy+
* Module `bug-krispy+` (class BugKrispyPlus, trong subproject bugpet, category "Astrix Finder") = KrispyChunkFinder cu.
* Logic giu nguyen: >= 55 vine (Y16-60) va >= 1 deepslate nam ngang (Y0-60). Cac nguong, ban kinh, tan suat quet, mau, Y ve deu la setting.
* Them thong bao (chuong + chat) cho moi chunk moi; khong con GL11/RenderUtils cua client Krispy, ve bang renderer cua Meteor.
* Chua compile/chay.

## v12 - bo tien to "skibidi-" khoi ten module (category "Astrix debug+")
* Patch constant pool trong libs/skibididebug-classes.jar (khong xoa module nao):
  skibidi-block-anomaly-debug -> block-anomaly-debug, skibidi-debug -> debug,
  skibidi-player-esp -> player-esp, skibidi-suspicious-esp -> suspicious-esp.
* 4 module bi TRUNG ten neu bo tien to (Meteor se xoa module cu cung ten khi add), nen them "+":
  skibidi-hole-esp -> hole-esp+ (trung hole-esp cua Meteor), skibidi-storage-esp -> storage-esp+ (trung storage-esp cua Meteor),
  skibidi-region-map -> region-map+ (trung region-map Astrix Music), skibidi-sus-chunk-finder -> sus-chunk-finder+ (trung sus-chunk-finder Astrix Finder).
* Setting da luu cua cac module nay se mat (doi ten = module moi).

## v13
* Astrix Finder: xoa 3 module chunk-finder, tuff-chunk-finder, player-chunk-finder (xoa file source + bo dang ky trong SkibidiDebugAddon). Cac module khac giu nguyen.

# Custom Models (Meteor addon, Fabric 1.21.11)

Đây là phần `src/main` của addon, KHÔNG kèm file gradle.

## Cách build
1. Clone https://github.com/MeteorDevelopment/meteor-addon-template (lấy bản/branch hỗ trợ 1.21.11,
   kiểm tra `gradle/libs.versions.toml` có `minecraft = 1.21.11`).
2. Xóa `src/main/java/com/example` và `src/main/resources/assets/template` + `addon-template.mixins.json`
   + `fabric.mod.json` cũ của template.
3. Copy thư mục `src/main` của zip này đè vào `src/main` của template.
4. Chạy `./gradlew build` -> jar nằm ở `build/libs/`.
5. Bỏ jar vào `mods/` cùng Meteor Client 1.21.11.

## Dùng
Module `Custom Models` (tab Render): chọn model, bật Self / Friends.

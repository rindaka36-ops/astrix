package dev.custommodels.addon.mixin;

import dev.custommodels.addon.CustomModelState;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.render.entity.state.PlayerEntityRenderState;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;

@Environment(EnvType.CLIENT)
@Mixin({PlayerEntityRenderState.class})
public class PlayerEntityRenderStateMixin implements CustomModelState {
    @Unique private String goobaa$customModel = "";
    @Unique private boolean goobaa$hasCustomModel;

    @Override
    public String goobaa$getCustomModel() {
        return this.goobaa$customModel;
    }

    @Override
    public boolean goobaa$hasCustomModel() {
        return this.goobaa$hasCustomModel;
    }

    @Override
    public void goobaa$setCustomModel(boolean goobaa$hasCustomModelValue, String text) {
        this.goobaa$hasCustomModel = goobaa$hasCustomModelValue;
        this.goobaa$customModel = text == null ? "" : text;
    }
}

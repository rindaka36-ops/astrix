package dev.custommodels.addon;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;

@Environment(EnvType.CLIENT)
public interface CustomModelState {
    boolean goobaa$hasCustomModel();

    void goobaa$setCustomModel(boolean flag, String text);

    String goobaa$getCustomModel();
}
